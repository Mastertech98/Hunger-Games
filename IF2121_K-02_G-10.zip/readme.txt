___________________________________________________________________________________________________________________
__00___00__00___00__0000000__0000000__0000000__0000000_________0000000___0000000___00_______00__0000000__0000000___
__00___00__00___00__00___00__00_______00_______00____00________00_______00_____00__0000___0000__00_______00________
__00___00__00___00__00___00__00_______00_______00____00________00_______00_____00__00_00_00_00__00_______00________
__0000000__00___00__00___00__00_0000__0000000__0000000_________00_0000__000000000__00___0___00__0000000__0000000___
__00___00__00___00__00___00__00___00__00_______00_00___________00___00__00_____00__00_______00__00____________00___
__00___00__00___00__00___00__00___00__00_______00__00__________00___00__00_____00__00_______00__00____________00___
__00___00___00000___00___00__0000000__0000000__00___00_________0000000__00_____00__00_______00__0000000__0000000___
___________________________________________________________________________________________________________________

Created by : - Ahmad Izzan (13516116)
			 - Manasye Shousen Bukit (13516122)
			 - Juan Felix Parsaoran Tarigan (13516143)
			 - William Juniarta Hadiman (13516026)

==================================================== HOW TO RUN ====================================================

In Windows :
1) First of all,you need to install Prolog . Especially in this program ,you need to install GNU Prolog.
   (SWI Prolog may have some slight of error due to different mechanism).
2) Open your GNU Prolog , find File toolbar and click consult.
3) Search the file with title main.pl and double click it.
4) Now you can play game and have fun :)

In Unix :
1) First, install gnu prolog from http://www.gprolog.org/#download
2) Open your terminal, and go to the prolog file directory
3) type in: gprolog
4) to compile / consult, type in: consult(file name), for example consult('hehe.pl')
5) Enjoy the game